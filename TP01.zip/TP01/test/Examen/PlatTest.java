package Examen;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Classe de tests pour la classe Plat.
 */
public class PlatTest {

    /**
     * Teste la méthode getNom() de la classe Plat.
     */
    @Test
    void testGetNom() {
        // Arrange
        String nom = "Spaghetti";
        double coutDeFabrication = 5.0;
        Plat plat = null;
        try {
            plat = new Plat(nom, coutDeFabrication);
        } catch (PlatException e) {
            e.printStackTrace();
        }

        // Act
        String resultat = plat.getNom();

        // Assert
        assertEquals(nom, resultat);
    }

    /**
     * Teste la méthode getCoutDeFabrication() de la classe Plat.
     */
    @Test
    void testGetCoutDeFabrication() {
        // Arrange
        String nom = "Spaghetti";
        double coutDeFabrication = 5.0;
        Plat plat = null;
        try {
            plat = new Plat(nom, coutDeFabrication);
        } catch (PlatException e) {
            e.printStackTrace();
        }

        // Act
        double resultat = plat.getCoutDeFabrication();

        // Assert
        assertEquals(coutDeFabrication, resultat);
    }

    /**
     * Teste la méthode getPrixDeVente() de la classe Plat.
     */
    @Test
    void testGetPrixDeVente() {
        // Arrange
        String nom = "Spaghetti";
        double coutDeFabrication = 5.0;
        Plat plat = null;
        try {
            plat = new Plat(nom, coutDeFabrication);
        } catch (PlatException e) {
            e.printStackTrace();
        }

        // Act
        double resultat = plat.getPrixDeVente();

        // Assert
        assertEquals(7.5, resultat);
    }
}
