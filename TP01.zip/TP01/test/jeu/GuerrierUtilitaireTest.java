package jeu;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * La classe GuerrierUtilitaireTest permet de tester les méthodes de la classe GuerrierUtilitaire.
 */
public class GuerrierUtilitaireTest {

    /**
     * Test de la méthode de3() de la classe GuerrierUtilitaire.
     * Vérifie si la méthode retourne un résultat entre 1 et 3 inclus.
     */
    @Test
    void testDe3() {
        int result = GuerrierUtilitaire.de3();
        assertTrue(result >= 1 && result <= 3, "Le résultat doit être entre 1 et 3 inclus");
    }

    /**
     * Test de la méthode de3(int nombreDes) de la classe GuerrierUtilitaire.
     * Vérifie si la méthode retourne un résultat entre 5 et 15 inclus pour 5 dés.
     */
    @Test
    void testDe3NombreDes() {
        int result = GuerrierUtilitaire.de3(5);
        assertTrue(result >= 5 && result <= 15, "Le résultat doit être entre 5 et 15 inclus");
    }

    /**
     * Test de la méthode afficherGuerrier(Guerrier guerrier) de la classe GuerrierUtilitaire.
     * Vérifie si l'affichage ne provoque pas d'exceptions lorsqu'elle est appelée avec un guerrier valide.
     */
    @Test
    void testAfficherGuerrier() {
        Guerrier guerrier = new Nain();
        assertDoesNotThrow(() -> GuerrierUtilitaire.afficherGuerrier(guerrier), "L'affichage ne devrait pas provoquer d'exceptions");
    }
}
