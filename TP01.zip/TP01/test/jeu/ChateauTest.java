package jeu;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * La classe de test `ChateauTest` permet de tester les fonctionnalités de la classe `Chateau`.
 */
public class ChateauTest {

    private Chateau chateau;

    /**
     * Méthode exécutée avant chaque test pour initialiser un nouveau château.
     */
    @BeforeEach
    void setUp() {
        chateau = new Chateau(Couleur.BLEU);
    }

    /**
     * Teste la méthode `entrainer()` de la classe `Chateau`.
     */
    @Test
    void testEntrainer() {
        // Ajouter des guerriers au château
        chateau.ajoutGuerrierNovice(new Nain());
        chateau.ajoutGuerrierNovice(new Elfe());

        // Entraîner les guerriers et vérifier le nombre d'entraînés
        Guerrier[] guerriersEntraines = chateau.entrainer();
        assertEquals(2, guerriersEntraines.length, "Le nombre de guerriers entraînés devrait être égal au nombre de guerriers novices");

        // Vérifier que les guerriers novices ont été entraînés
        for (Guerrier guerrier : guerriersEntraines) {
            assertTrue(guerrier instanceof Nain || guerrier instanceof Elfe, "Les guerriers entraînés doivent être soit des Nains soit des Elfes");
        }
    }

    /**
     * Teste la méthode `incrementerRessources()` de la classe `Chateau`.
     */
    @Test
    void testIncrementerRessources() {
        int ressourcesAvant = chateau.getRessources();
        chateau.incrementerRessources();
        assertEquals(ressourcesAvant + 1, chateau.getRessources(), "Le nombre de ressources devrait être incrémenté de 1");
    }
}
