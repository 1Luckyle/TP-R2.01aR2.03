package tp6;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ArticleTest {
    @Test
    void getIntitule() throws IntituleException, PrixException, StockException {
        Article article = new Article("test", 10.0, 100);
        assertEquals("Test", article.getIntitule());
    }

    @Test
    void setIntitule() throws IntituleException, PrixException, StockException {
        Article article = new Article("", 10.0, 100);
        assertThrows(IntituleException.class, () -> article.setIntitule(""));
    }

    @Test
    void getPrix() throws PrixException, IntituleException, StockException {
        Article article = new Article("test", 10.0, 100);
        assertEquals(10.0, article.getPrix());
    }

    @Test
    void setPrix() throws PrixException, IntituleException, StockException {
        Article article = new Article("test", 10.0, 100);
        article.setPrix(20.0);
        assertEquals(20.0, article.getPrix());
    }

    @Test
    void existQuantite() throws PrixException, IntituleException, StockException {
        Article article = new Article("test", 10.0, 100);
        assertTrue(article.existQuantite(50));
        assertFalse(article.existQuantite(150));
    }

    @Test
    void removeQuantite() throws PrixException, IntituleException, StockException {
        Article article = new Article("test", 10.0, 100);
        article.removeQuantite(50);
        assertEquals(50, article.getStock());
    }
}
