/**
 * La classe Etudiant représente la notion d'étudiant (login, nom, prénom et adresse).
 * ATTENTION des contraintes sur la notion d’étudiant :
 * – un étudiant doit toujours avoir un login en minuscule
 * – un étudiant doit toujours avoir un nom et un prénom avec le premier caractère en majuscule et les autres en minuscule.
 */
public class Etudiant {
    /* Initialisation des variables [Attributs de classe] */
    private String login, prenom, nom, adresse;
    private int nbnotes = 0;
    private Groupe groupe;
    private double[] notes = new double[5];

    /* ETUDIANT */
    public Etudiant(String login, String prenom, String nom) {
        setLogin(login);
        setPrenom(prenom.toLowerCase());
        setNom(nom.toLowerCase());
        setGroupe(null);
    }

    public void addNote(double note) {
        if (nbnotes < 5) {
            notes[nbnotes] = note;
            nbnotes++;
        }
    }

    /* GETTERS / ACCESSEURS*/
    public String getLogin() {
        return login;
    }
    public String getPrenom() {
        return prenom;
    }
    public String getNom() {
        return nom;
    }
    public String getAdresse() {
        return adresse;
    }
    public String getNomComplet() {
        return nom.concat(prenom);
    }
    public String getMail() {
        return prenom.concat(".").concat(nom).concat("@").concat("etu.univ-grenoble-alpes.fr");
    }

    public int getNbnotes() {
        return nbnotes;
    }

    public double[] getNotes() {
        return notes;
    }

    public double getMoyenne() {
        double moyenne = 0;
        for (int i = 0 ; i < nbnotes ; i++) {
            moyenne += notes[i];
        }
        return moyenne / nbnotes;
    }

    public Groupe getGroupe() {
        return groupe;
    }

    /* VERIFICATEURS : */
    public boolean existAdresse() {
        return adresse != null && !adresse.isEmpty(); // Vérifier si l'adresse n'est pas nulle et n'est pas vide
    }

    public boolean existMoyenne() {
        return nbnotes != 0; // Vérifier si le nombre de notes est supérieur à 0
    }

    public boolean existGroupe() {
        return groupe != null; // Vérifier si il y a un groupe ou non
    }

    /* SETTERS */
    public void setLogin(String login) {
        this.login = login.toLowerCase();
    }
    public void setPrenom(String prenom) {
        this.prenom = EtudiantUtilitaire.capitalize(prenom);;;
    }
    public void setNom(String nom) {
        this.nom = EtudiantUtilitaire.capitalize(nom);;
    }
    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public void setGroupe(Groupe groupe) {
      this.groupe = groupe;
    }
}
