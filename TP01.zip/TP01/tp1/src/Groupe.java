public class Groupe {
    private String libelle;

    public Groupe(String libelle) {
        this.libelle = libelle;
    }

    public String getLibelle() {
        return libelle;
    }
}
