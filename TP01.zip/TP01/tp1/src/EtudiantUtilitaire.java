import java.util.Arrays;

public class EtudiantUtilitaire {
    public static String capitalize(String maChaine) {
        if (maChaine == null || maChaine.isEmpty()) {
            return maChaine;
        }
        return maChaine.substring(0, 1).toUpperCase() + maChaine.substring(1);
    }
        public static void afficheEtudiant(Etudiant etudiant) {
            System.out.println("\n|━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━|");
            System.out.println("Login : " + etudiant.getLogin());
            System.out.println("Nom complet : " + etudiant.getNomComplet());
            System.out.println("Mail : " + etudiant.getMail());
            if (etudiant.existGroupe() == true) {
                System.out.println("Groupe : " + etudiant.getGroupe().getLibelle());
            }
            System.out.println("Adresse : " + (etudiant.existAdresse() ? etudiant.getAdresse() : "Aucune Adresse"));
            System.out.println("Moyenne : " + (etudiant.existMoyenne() ? etudiant.getMoyenne() : "Aucune Note"));
            if (etudiant.getNbnotes() > 0) {
                System.out.println(etudiant.getNbnotes() + " notes : " + Arrays.toString(etudiant.getNotes()));
            }
            System.out.println("|━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━|");
        }
    }
