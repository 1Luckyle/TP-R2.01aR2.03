public class TestEtudiant {
    public static void main(String[] args) {
        // Création des étudiants
        // IMPORTANT mettre des valeurs qui ne respectent pas les contraintes pour vérifier leur prise en compte
        Etudiant etudiant1 = new Etudiant("DUPONTP", "pierre", "dupoNT");
        Etudiant etudiant2 = new Etudiant("martinf", "francis", "martin");

        // Ajouter une adresse
        etudiant2.setAdresse("2 Place Doyen Gosse");

        // Ajouter des notes
        etudiant1.addNote(8.5);
        etudiant1.addNote(10.0);
        etudiant1.addNote(11.5);

        // Création d'un groupe
        Groupe groupeA = new Groupe("A");

        // Affecter le groupe à un étudiant
        etudiant1.setGroupe(groupeA);

        // Afficher les etudiants
        EtudiantUtilitaire.afficheEtudiant(etudiant1);
        EtudiantUtilitaire.afficheEtudiant(etudiant2);
    }
}



