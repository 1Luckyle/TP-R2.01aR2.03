package tp6;

public class ArticleUtilitaire {
    public static String capitalize(String maChaine) {
        if (maChaine == null || maChaine.isEmpty()) {
            return maChaine;
        }
        return maChaine.substring(0, 1).toUpperCase() + maChaine.substring(1).toLowerCase();
    }
}
