package tp6;

public class IntituleException extends Exception {
    public IntituleException(String message) {
        super(message);
    }
}
