package tp6;

public class PrixException extends Exception {
    public PrixException(String message) {
        super(message);
    }
}
