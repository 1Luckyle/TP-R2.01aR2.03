package tp6;

public class Article {
    private String intitule;
    private double prix;
    private int stock;

    public Article(String intitule, double prix, int stock) throws IntituleException, PrixException, StockException {
        setIntitule(intitule);
        setPrix(prix);
        setStock(stock);
    }

    public String getIntitule() {
        return intitule;
    }

    public void setIntitule(String intitule) throws IntituleException {
        if (intitule == null || intitule.isEmpty()) {
            throw new IntituleException("L'intitulé ne peut pas être null ou vide");
        }
        this.intitule = ArticleUtilitaire.capitalize(intitule);
    }

    public double getPrix() {
        return prix;
    }

    public double getPrix(int quantite) {
        final int SEUIL = 100;
        if (quantite >= SEUIL) {
            return getPrix() * quantite * 0.9;
        } else {
            return getPrix() * quantite;
        }
    }

    public void setPrix(double prix) throws PrixException {
        if (prix <= 0) {
            throw new PrixException("Le prix ne peut pas être nul ou négatif !");
        }
        this.prix = prix;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) throws StockException {
        if (stock <= 0) {
            throw new StockException("Le stock ne peut pas être nul ou négatif !");
        }
        this.stock = stock;
    }

    public boolean existQuantite(int quantite) {
        return quantite <= getStock();
    }

    public void removeQuantite(int quantite) throws StockException {
        if (!existQuantite(quantite)) {
            throw new StockException("La quantité demandée n'est pas disponible dans le stock !");
        }
        setStock(getStock() - quantite);
    }
}
