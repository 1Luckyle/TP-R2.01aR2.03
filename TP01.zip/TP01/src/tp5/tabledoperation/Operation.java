package tp5.tabledoperation;

public abstract class Operation {
    private double terme1;
    private double terme2;
    private Double responseUtilisateur;

    public Operation(double terme1, double terme2) {
        this.terme1 = terme1;
        this.terme2 = terme2;
    }

    public void setResponseUtilisateur(Double responseUtilisateur) {
        this.responseUtilisateur = responseUtilisateur;
    }

    public boolean existeReponseUtilisateur() {
        if (responseUtilisateur != null) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isReponseJuste() {
        if (existeReponseUtilisateur()) {
            return calculResultat() == responseUtilisateur;
        } else {
            return false;
        }
    }

    public abstract double calculResultat();

    public double getTerme1() {
        return terme1;
    }

    public double getTerme2() {
        return terme2;
    }
}
