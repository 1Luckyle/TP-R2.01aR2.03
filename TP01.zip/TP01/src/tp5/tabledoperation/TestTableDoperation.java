package tp5.tabledoperation;

import java.util.logging.Logger;

public class TestTableDoperation {
    // Récupération du logger
    private static Logger LOGGER = Logger.getLogger(TableDOperation.class.getPackageName());

    public static void main(String[] args) {

    }
}
