package tp5.tabledoperation;

public class TableDOperation {
    private OperationEnum typeOperation;

    public TableDOperation(OperationEnum typeOperation) {
        this.typeOperation = typeOperation;
        initialisation();
    }

    private void initialisation() {

    }

    public int getNombreReponsesJustes() {
        return 0;
    }

    public int getNombreDOperations() {
        return 0;
    }

    public Operation getOperation(int index) {
        this.typeOperation = typeOperation;
        return null;
    }
}
