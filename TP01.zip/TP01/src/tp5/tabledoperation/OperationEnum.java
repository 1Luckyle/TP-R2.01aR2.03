package tp5.tabledoperation;

public enum OperationEnum {
        ADDITION("addition"),
        SOUSTRACTION("soustraction"),
        MULITIPLICATION("multiplication");
        private String libelle;

        private OperationEnum(String libelle) {
            this.libelle = libelle;
        }
        @Override
        public String toString() {
            return libelle;
        }
}
