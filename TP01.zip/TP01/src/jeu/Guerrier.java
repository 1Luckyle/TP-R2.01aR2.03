package jeu;

/**
 * La classe `Guerrier` représente un personnage de type guerrier dans le jeu Faërun.
 * Un guerrier possède une certaine force et un certain nombre de points de vie.
 */
public class Guerrier {
    /** La force du guerrier */
    private int force;

    /** Les points de vie du guerrier */
    private int pointsDeVie;

    /**
     * Constructeur par défaut de la classe `Guerrier`.
     * Initialise la force à 10 et les points de vie à 100.
     */
    public Guerrier() {
        this.force = 10; // Initialisation de la force à 10
        this.pointsDeVie = 100; // Initialisation des points de vie à 100
    }

    /**
     * Obtient la force du guerrier.
     * @return La force du guerrier.
     */
    public int getForce() {
        return force;
    }

    /**
     * Obtient les points de vie du guerrier.
     * @return Les points de vie du guerrier.
     */
    public int getPointsDeVie() {
        return pointsDeVie;
    }

    /**
     * Modifie les points de vie du guerrier.
     * @param pointsDeVie Les nouveaux points de vie du guerrier.
     */
    public void setPointsDeVie(int pointsDeVie) {
        this.pointsDeVie = pointsDeVie;
    }

    /**
     * Vérifie si le guerrier est encore vivant.
     * @return true si le guerrier est vivant (points de vie > 0), sinon false.
     */
    public boolean estVivant() {
        return pointsDeVie > 0;
    }

    /**
     * Attaque un autre guerrier en infligeant des dégâts.
     * @param guerrierCible Le guerrier cible de l'attaque.
     */
    public void attaquer(Guerrier guerrierCible) {
        int degatsInfliges = GuerrierUtilitaire.de3(this.force);
        guerrierCible.subirDegats(degatsInfliges);
    }

    /**
     * Fait subir des dégâts au guerrier.
     * @param degats Les dégâts à infliger au guerrier.
     */
    protected void subirDegats(int degats) {
        pointsDeVie -= degats;
    }
}
