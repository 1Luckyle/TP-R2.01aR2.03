package jeu;

/**
 * La classe `ChefElfe` représente un personnage de type chef elfe dans le jeu Faërun.
 * Un chef elfe possède les caractéristiques d'un elfe mais avec une force encore plus grande.
 */
public class ChefElfe extends Elfe {
    /**
     * Redéfinition de la méthode getForce pour un chef elfe.
     * Augmente la force du chef elfe de deux fois supplémentaires par rapport à un elfe.
     * @return La force du chef elfe.
     */
    @Override
    public int getForce() {
        return super.getForce() * 2;
    }
}
