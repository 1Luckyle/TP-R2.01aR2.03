package jeu;

import java.util.ArrayList;
import java.util.List;

public class Chateau {

    private static final int RESSOURCES_INITIAL = 3;
    private static final int RESSOURCE_AJOUTEE_PAR_TOUR = 1;

    private int ressources;
    private final Couleur couleur;
    private List<Guerrier> guerriersNovices;

    public Chateau(Couleur couleur) {
        this.couleur = couleur;
        this.ressources = RESSOURCES_INITIAL;
        this.guerriersNovices = new ArrayList<>();
    }

    public void ajoutGuerrierNovice(Guerrier guerrier) {
        guerriersNovices.add(guerrier);
    }

    /**
     * Entraîne les guerriers novices du château en fonction de ses ressources disponibles.
     * @return Un tableau contenant les guerriers entraînés.
     */
    public Guerrier[] entrainer() {
        List<Guerrier> guerriersEntraines = new ArrayList<>();

        for (Guerrier guerrier : guerriersNovices) {
            int coutEntrainement = guerrier.getCoutEntrainement();
            if (coutEntrainement <= ressources) {
                guerriersEntraines.add(guerrier);
                ressources -= coutEntrainement;
            }
        }

        return guerriersEntraines.toArray(new Guerrier[0]);
    }

    public void incrementerRessources() {
        ressources += RESSOURCE_AJOUTEE_PAR_TOUR;
    }

    public Couleur getCouleur() {
        return couleur;
    }

    public boolean estBleu() {
        return couleur == Couleur.BLEU;
    }

    public boolean estRouge() {
        return couleur == Couleur.ROUGE;
    }

    public int getRessources() {
        return ressources;
    }

    @Override
    public String toString() {
        return "château " + couleur + " : " + ressources + " ressources";
    }
}
