package jeu;

/**
 *
 * Cette Javadoc fournit des commentaires détaillés pour la classe `TestGuerrier`, expliquant son rôle ainsi
 * que la manière dont elle teste les fonctionnalités de la classe `Guerrier`.
 * La classe `TestGuerrier` permet de tester les fonctionnalités de la classe `Guerrier`.
 * Elle simule un combat entre deux guerriers.
 */
public class TestGuerrier {
    /**
     * Méthode principale du programme.
     * @param args Les arguments de la ligne de commande (non utilisés dans ce programme).
     */
    public static void main(String[] args) {
        // Création de deux guerriers
        Guerrier guerrier1 = new Guerrier();
        Guerrier guerrier2 = new Guerrier();

        // Combat entre les deux guerriers
        int tour = 1;
        while (guerrier1.estVivant() && guerrier2.estVivant()) {
            System.out.println("|━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━|");
            System.out.println("Tour " + tour + " : \n");
            GuerrierUtilitaire.afficherGuerrier(guerrier1);
            GuerrierUtilitaire.afficherGuerrier(guerrier2);

            int degatsGuerrier1 = GuerrierUtilitaire.de3(guerrier1.getForce());
            guerrier2.subirDegats(degatsGuerrier1);
            if (!guerrier2.estVivant()) {
                System.out.println("Le guerrier 2 est mort. Le guerrier 1 remporte le combat.");
                System.out.println("|━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━|\n");
                break;
            }

            int degatsGuerrier2 = GuerrierUtilitaire.de3(guerrier2.getForce());
            guerrier1.subirDegats(degatsGuerrier2);
            if (!guerrier1.estVivant()) {
                System.out.println("Le guerrier 1 est mort. Le guerrier 2 remporte le combat.");
                System.out.println("|━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━|\n");
                break;
            }
            System.out.println("|━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━|\n");
            tour++;
        }
    }
}

