package jeu;

/**
 * La classe `GuerrierUtilitaire` contient des méthodes utilitaires pour la gestion des guerriers dans le jeu Faërun.
 */
public class GuerrierUtilitaire {
    /**
     * Affiche les informations sur un guerrier, y compris ses points de vie et sa force.
     * @param guerrier Le guerrier dont les informations doivent être affichées.
     */
    public static void afficherGuerrier(Guerrier guerrier) {
        System.out.println("Guerrier - Points de vie : " + guerrier.getPointsDeVie());
        System.out.println("Guerrier - Force : " + guerrier.getForce());
    }

    /**
     * Lance un dé de trois faces et retourne le résultat.
     * @return Un entier aléatoire entre 1 et 3 inclus.
     */
    public static int de3() {
        return (int) (Math.random() * 3) + 1;
    }

    /**
     * Lance un nombre spécifié de dés de trois faces et retourne la somme des résultats.
     * @param nombreLances Le nombre de dés à lancer.
     * @return La somme des résultats des lancers de dés.
     */
    public static int de3(int nombreLances) {
        int somme = 0;
        for (int i = 0; i < nombreLances; i++) {
            somme += de3();
        }
        return somme;
    }
}
