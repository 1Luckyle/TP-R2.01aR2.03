package jeu;

/**
 * La classe `Nain` représente un personnage de type nain dans le jeu Faërun.
 * Un nain possède une force réduite par rapport à un guerrier de base.
 */
public class Nain extends Guerrier {
    /**
     * Redéfinition de la méthode subirDegats pour un nain.
     * Réduit les dégâts subis par un nain de moitié par rapport à un guerrier de base.
     * @param degats Les dégâts à infliger au nain.
     */
    @Override
    protected void subirDegats(int degats) {
        super.subirDegats(degats / 2);
    }
}
