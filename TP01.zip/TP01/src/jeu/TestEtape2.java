package jeu;

/**
 * La classe `TestEtape2` contient des tests pour les nouvelles classes de guerriers introduites dans l'étape 2.
 * Elle valide les spécifications en effectuant des combats entre différentes classes de guerriers et en affichant les dégâts infligés.
 */
public class TestEtape2 {
    /**
     * Méthode principale pour exécuter les tests.
     * @param args Les arguments de la ligne de commande (non utilisés dans ce programme).
     */
    public static void main(String[] args) {
        // Création de différents guerriers pour les tests
        Nain nain = new Nain();
        ChefNain chefNain = new ChefNain();
        Elfe elfe = new Elfe();
        ChefElfe chefElfe = new ChefElfe();

        // Combat entre un nain et un elfe
        System.out.println("Combat entre un nain et un elfe :");
        combat(nain, elfe);

        // Combat entre un chef nain et un chef elfe
        System.out.println("\nCombat entre un chef nain et un chef elfe :");
        combat(chefNain, chefElfe);

        // Combat entre un elfe et un chef nain
        System.out.println("\nCombat entre un elfe et un chef nain :");
        combat(elfe, chefNain);
    }

    /**
     * Effectue un combat entre un attaquant et un défenseur.
     * Affiche les dégâts infligés par l'attaquant et les dégâts réellement subis par le défenseur.
     * @param attaquant Le guerrier qui attaque.
     * @param defenseur Le guerrier qui se défend.
     */
    public static void combat(Guerrier attaquant, Guerrier defenseur) {
        // Affichage des informations initiales
        System.out.println("Points de vie du défenseur avant l'attaque : " + defenseur.getPointsDeVie());
        System.out.println("Force de l'attaquant : " + attaquant.getForce());

        // Attaque
        attaquant.attaquer(defenseur);

        // Affichage des dégâts donnés par l'attaquant et des dégâts réellement subis par le défenseur
        System.out.println("Dégâts donnés par l'attaquant : " + attaquant.getForce());
        System.out.println("Dégâts subis par le défenseur : " + defenseur.getPointsDeVie());

        // Affichage des points de vie restants du défenseur
        System.out.println("Points de vie du défenseur après l'attaque : " + defenseur.getPointsDeVie());
    }
}
