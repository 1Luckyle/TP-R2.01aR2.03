package jeu;

import java.util.logging.Logger;

/**
 * La classe `TestJeuEtape3` permet de tester les fonctionnalités du jeu Faërun à l'étape 3.
 * Cette étape inclut l'ajout de guerriers au château, leur entraînement, l'affichage des guerriers prêts au combat,
 * la gestion des ressources du château, ainsi que la simulation de plusieurs tours.
 */
public class TestJeuEtape3 {

    // Création d'un logger pour la classe TestJeuEtape3
    private static final Logger LOGGER = Logger.getLogger(TestJeuEtape3.class.getName());

    /**
     * Méthode principale du programme de test.
     * @param args Les arguments de la ligne de commande (non utilisés dans ce programme).
     */
    public static void main(String[] args) {

        // Création d'un objet chateau
        Chateau chateau = new Chateau(Couleur.BLEU);

        // Ajouter des guerriers au chateau
        chateau.ajoutGuerrierNovice(new Nain());
        chateau.ajoutGuerrierNovice(new Nain());
        chateau.ajoutGuerrierNovice(new Elfe());
        chateau.ajoutGuerrierNovice(new Elfe());

        // Afficher les guerriers contenu dans le chateau (dans l'ordre d'entrainement)
        LOGGER.info("Guerriers dans le château avant l'entraînement :");
        for (Guerrier guerrier : chateau.entrainer()) {
            LOGGER.info(guerrier.toString());
        }

        // Réaliser un premier entrainement puis afficher les guerriers prets aux combats
        LOGGER.info("\nEntraînement en cours...");
        chateau.entrainer();
        LOGGER.info("\nGuerriers prêts après le premier entraînement :");
        for (Guerrier guerrier : chateau.entrainer()) {
            LOGGER.info(guerrier.toString());
        }

        // Afficher le nombre de ressources disponibles dans le chateau
        LOGGER.info("Nombre de ressources disponibles : " + chateau.getRessources());

        // Afficher combien il manque de ressources pour le guerrier entraîné en question
        for (Guerrier guerrier : chateau.entrainer()) {
            int coutEntrainement = guerrier.getCoutEntrainement();
            int ressourcesRestantes = chateau.getRessources() - coutEntrainement;
            if (ressourcesRestantes >= 0) {
                LOGGER.info("Il manque " + ressourcesRestantes + " ressources pour entraîner le guerrier.");
            } else {
                LOGGER.info("Pas assez de ressources pour entraîner le guerrier.");
            }
        }

        // Réaliser une itération pour simuler 10 tours : entraînement, affichage des guerriers prêts et incrémentation des ressources
        for (int tour = 1; tour <= 10; tour++) {
            LOGGER.info("\nTour " + tour + " :");
            chateau.incrementerRessources(); // Simuler l'incrémentation des ressources à chaque tour
            chateau.entrainer(); // Entraînement des guerriers avec les ressources disponibles
            LOGGER.info("\nGuerriers prêts après le tour " + tour + " :");
            for (Guerrier guerrier : chateau.entrainer()) {
                LOGGER.info(guerrier.toString());
            }
        }
    }
}
