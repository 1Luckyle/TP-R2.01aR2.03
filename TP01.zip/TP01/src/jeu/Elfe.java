package jeu;

/**
 * La classe `Elfe` représente un personnage de type elfe dans le jeu Faërun.
 * Un elfe possède une force accrue par rapport à un guerrier de base.
 */
public class Elfe extends Guerrier {
    /**
     * Redéfinition de la méthode getForce pour un elfe.
     * Augmente la force de l'elfe de deux fois par rapport à un guerrier de base.
     * @return La force de l'elfe.
     *
     */
    @Override
    public int getForce() {
        return super.getForce() * 2;
    }
}
