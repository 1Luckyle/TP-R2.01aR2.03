package jeu;

/**
 * La classe `ChefNain` représente un personnage de type chef nain dans le jeu Faërun.
 * Un chef nain possède les caractéristiques d'un nain mais avec une capacité de résistance accrue.
 */
public class ChefNain extends Nain {
    /**
     * Redéfinition de la méthode subirDegats pour un chef nain.
     * Réduit les dégâts subis par un chef nain de moitié supplémentaire par rapport à un nain.
     * @param degats Les dégâts à infliger au chef nain.
     */
    @Override
    protected void subirDegats(int degats) {
        super.subirDegats(degats / 2);
    }
}
