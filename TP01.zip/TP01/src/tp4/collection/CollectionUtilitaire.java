package tp4.collection;

import java.util.Collection;
import java.util.Iterator;

public class CollectionUtilitaire {
    public static void afficheCollection(String message, Collection collection) {
        System.out.println(message);
        Iterator itr = collection.iterator();
        while (itr.hasNext()) {
            Object element = itr.next();
            System.out.print(element + " ");
        }
        System.out.println();
    }
}
