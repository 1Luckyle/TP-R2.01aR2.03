package tp4.tabledemultiplication;

public class TableDeMultiplication {
    private int nombreTable;

    public TableDeMultiplication(int nombreTable, boolean estMelange) {
        this.nombreTable = nombreTable;
    }
}