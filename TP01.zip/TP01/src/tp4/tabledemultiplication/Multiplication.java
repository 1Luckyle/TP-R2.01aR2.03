package tp4.tabledemultiplication;

public class Multiplication {
    private int terme1;
    private int terme2;
    private Integer reponseUtilisateur;

    public Multiplication(int terme1, int terme2) {
        this.terme1 = terme1;
        this.terme2 = terme2;
    }

    public void setReponseUtilisateur(int reponse) {
        this.reponseUtilisateur = reponse;
    }

    public boolean isReponseJuste() {
        if (reponseUtilisateur == null) {
            return false;
        }
        return reponseUtilisateur == (terme1 * terme2);
    }

    @Override
    public String toString() {
        return terme1 + " x " + terme2 + " = ";
    }
}
