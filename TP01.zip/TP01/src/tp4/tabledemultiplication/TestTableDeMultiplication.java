package tp4.tabledemultiplication;

public class TestTableDeMultiplication {
//    public static void main(String[] args) {
//        TableDeMultiplication table = new TableDeMultiplication(5, true);
//
//        for (int i = 0; i < table.getNombreDeMultiplications(); i++) {
//            Multiplication multiplication = table.getMultiplication(i);
//            System.out.println(multiplication);
//        }
//    }
}
