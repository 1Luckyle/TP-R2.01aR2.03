package Examen;

/**
 * Représente un menu de base contenant une entrée et un plat principal.
 */
public class MenuDeBase {
    private String nom;
    private Plat entree;
    private Plat platPrincipal;

    /**
     * Constructeur de MenuDeBase.
     *
     * @param nom           Le nom du menu.
     * @param entree        L'entrée du menu.
     * @param platPrincipal Le plat principal du menu.
     */
    public MenuDeBase(String nom, Plat entree, Plat platPrincipal) {
        this.nom = nom;
        this.entree = entree;
        this.platPrincipal = platPrincipal;
    }

    /**
     * Obtient le nom du menu.
     *
     * @return Le nom du menu.
     */
    public String getNom() {
        return nom;
    }

    /**
     * Obtient l'entrée du menu.
     *
     * @return L'entrée du menu.
     */
    public Plat getEntree() {
        return entree;
    }

    /**
     * Obtient le plat principal du menu.
     *
     * @return Le plat principal du menu.
     */
    public Plat getPlatPrincipal() {
        return platPrincipal;
    }

    /**
     * Obtient le prix de vente du menu avant remise.
     *
     * @return Le prix de vente du menu avant remise.
     */
    protected double getPrixDeVenteAvantRemise() {
        return entree.getPrixDeVente() + platPrincipal.getPrixDeVente();
    }

    /**
     * Obtient le prix de vente du menu.
     *
     * @return Le prix de vente du menu.
     */
    public double getPrixDeVente() {
        return CarteUtilitaire.arrondi(getPrixDeVenteAvantRemise() * 0.8);
    }

    /**
     * Obtient la description du menu.
     *
     * @return La description du menu.
     */
    public String getDescription() {
        return nom + " :\n\tEntrée : " + entree.getNom() + "\n\tPlat principal : " + platPrincipal.getNom();
    }
}
