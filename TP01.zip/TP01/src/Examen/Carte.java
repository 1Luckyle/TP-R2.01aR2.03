package Examen;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Représente une carte de restaurant contenant différents plats et menus.
 */
public class Carte {
    private List<Plat> entrees = new ArrayList<>();          // Liste des entrées disponibles sur la carte
    private List<Plat> platsPrincipaux = new ArrayList<>();  // Liste des plats principaux disponibles sur la carte
    private List<Plat> desserts = new ArrayList<>();         // Liste des desserts disponibles sur la carte
    private List<MenuDeBase> menus = new ArrayList<>();      // Liste des menus disponibles sur la carte

    /**
     * Ajoute une entrée à la carte.
     *
     * @param entree L'entrée à ajouter.
     */
    public void addEntree(Plat entree) {
        entrees.add(entree);
    }

    /**
     * Ajoute un plat principal à la carte.
     *
     * @param platPrincipal Le plat principal à ajouter.
     */
    public void addPlatPrincipal(Plat platPrincipal) {
        platsPrincipaux.add(platPrincipal);
    }

    /**
     * Ajoute un dessert à la carte.
     *
     * @param dessert Le dessert à ajouter.
     */
    public void addDessert(Plat dessert) {
        desserts.add(dessert);
    }

    /**
     * Ajoute un menu à la carte.
     *
     * @param menuDeBase Le menu à ajouter.
     */
    public void addMenu(MenuDeBase menuDeBase) {
        menus.add(menuDeBase);
    }

    /**
     * Récupère la collection des entrées disponibles sur la carte.
     *
     * @return La collection des entrées disponibles sur la carte.
     */
    public Collection<Plat> getEntrees() {
        return entrees;
    }

    /**
     * Récupère la collection des plats principaux disponibles sur la carte.
     *
     * @return La collection des plats principaux disponibles sur la carte.
     */
    public Collection<Plat> getPlatsPrincipaux() {
        return platsPrincipaux;
    }

    /**
     * Récupère la collection des desserts disponibles sur la carte.
     *
     * @return La collection des desserts disponibles sur la carte.
     */
    public Collection<Plat> getDesserts() {
        return desserts;
    }

    /**
     * Récupère la collection des menus disponibles sur la carte.
     *
     * @return La collection des menus disponibles sur la carte.
     */
    public Collection<MenuDeBase> getMenus() {
        return menus;
    }
}
