package Examen;

/**
 * Représente un menu complet contenant une entrée, un plat principal et un dessert.
 */
public class MenuComplet extends MenuDeBase {
    private Plat dessert;

    /**
     * Constructeur de MenuComplet.
     *
     * @param nom           Le nom du menu.
     * @param entree        L'entrée du menu.
     * @param platPrincipal Le plat principal du menu.
     * @param dessert       Le dessert du menu.
     */
    public MenuComplet(String nom, Plat entree, Plat platPrincipal, Plat dessert) {
        super(nom, entree, platPrincipal);
        this.dessert = dessert;
    }

    /**
     * Obtient le dessert du menu.
     *
     * @return Le dessert du menu.
     */
    public Plat getDessert() {
        return dessert;
    }

    /**
     * Obtient le prix de vente du menu avant remise.
     *
     * @return Le prix de vente du menu avant remise.
     */
    protected double getPrixDeVenteAvantRemise() {
        return super.getPrixDeVenteAvantRemise() + dessert.getPrixDeVente();
    }

    /**
     * Obtient la description du menu.
     *
     * @return La description du menu.
     */
    public String getDescription() {
        return super.getDescription() + "\n\tDessert : " + dessert.getNom();
    }
}
