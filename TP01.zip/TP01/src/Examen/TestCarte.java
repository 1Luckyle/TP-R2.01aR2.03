package Examen;

/**
 *  Classe de test pour la création d'une carte
 *
 */
public class TestCarte {

    public static void main(String[] args) throws PlatException {
        // Création des plats
        Plat entree1 = new Plat("Taboulé", 3);
        Plat entree2 = new Plat("Croquettes de carottes", 6);
        Plat entree3 = new Plat("Chèvre en feuilleté", 9);
        Plat plat1 = new Plat("Paupiette de veau aux olives et son gratin", 6);
        Plat plat2 = new Plat("Filet de lieu sauce armoricaine et son riz", 9);
        Plat plat3 = new Plat("Crumble de ravioles/épinards", 12);
        Plat dessert1 = new Plat("Fondant au chocolat", 3);
        Plat dessert2 = new Plat("Flan pâtissier traditionnel", 5);
        Plat dessert3 = new Plat("Brownies aux noix", 6);

        // Création des menus
        MenuDeBase menu1 = new MenuDeBase("Essentiel", entree1, plat1);
        MenuDeBase menu2 = new MenuDeBase("Inspiration", entree2, plat2);
        MenuComplet menu3 = new MenuComplet("Gourmand", entree3, plat3, dessert3);

        // Création de la carte
        Carte carte = new Carte();

        // Ajout des plats à la carte
        carte.addEntree(entree1);
        carte.addEntree(entree2);
        carte.addEntree(entree3);
        carte.addPlatPrincipal(plat1);
        carte.addPlatPrincipal(plat2);
        carte.addPlatPrincipal(plat3);
        carte.addDessert(dessert1);
        carte.addDessert(dessert2);
        carte.addDessert(dessert3);

        // Ajout des menus à la carte
        carte.addMenu(menu1);
        carte.addMenu(menu2);
        carte.addMenu(menu3);

        // Affichage de la carte
        System.out.println("Menu : Essentiel - " + menu1.getPrixDeVente() + " euros");
        System.out.println("\tEntree : " + entree1.getNom());
        System.out.println("\tPlat principal : " + plat1.getNom());
        System.out.println();

        System.out.println("Menu : Inspiration - " + menu2.getPrixDeVente() + " euros");
        System.out.println("\tEntree : " + entree2.getNom());
        System.out.println("\tPlat principal : " + plat2.getNom());
        System.out.println();

        System.out.println("Menu : Gourmand - " + menu3.getPrixDeVente() + " euros");
        System.out.println("\tEntree : " + entree3.getNom());
        System.out.println("\tPlat principal : " + plat3.getNom());
        System.out.println("\tDessert : " + dessert3.getNom());
        System.out.println();

        System.out.println("Nos entrées :");
        for (Plat entree : carte.getEntrees()) {
            System.out.println("\t" + entree.getNom() + " - " + entree.getPrixDeVente() + " euros");
        }
        System.out.println();

        System.out.println("Nos plats :");
        for (Plat plat : carte.getPlatsPrincipaux()) {
            System.out.println("\t" + plat.getNom() + " - " + plat.getPrixDeVente() + " euros");
        }
        System.out.println();

        System.out.println("Nos desserts :");
        for (Plat dessert : carte.getDesserts()) {
            System.out.println("\t" + dessert.getNom() + " - " + dessert.getPrixDeVente() + " euros");
        }
    }
}
