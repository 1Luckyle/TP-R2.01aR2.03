package Examen;

/**
 * Classe utilitaire pour les opérations liées à la carte.
 */
public class CarteUtilitaire {

    /**
     * Arrondit un nombre à l'entier le plus proche supérieur ou égal.
     *
     * @param valeur Le nombre à arrondir.
     * @return L'entier le plus proche supérieur ou égal à la valeur spécifiée.
     */
    public static double arrondi(double valeur) {
        return Math.ceil(valeur);
    }

    /**
     * Transforme la première lettre d'une chaîne de caractères en majuscule et le reste en minuscules.
     *
     * @param chaine La chaîne de caractères à capitaliser.
     * @return La chaîne avec la première lettre en majuscule et le reste en minuscules.
     */
    public static String capitalize(String chaine) {
        return chaine.substring(0, 1).toUpperCase() + chaine.substring(1).toLowerCase();
    }

    /**
     * Affiche la carte sur le terminal.
     *
     * @param carte La carte à afficher.
     */
    public static void printCarte(Carte carte) {
        // Affichage des menus
        for (MenuDeBase menu : carte.getMenus()) {
            System.out.println(menu.getDescription() + " - " + menu.getPrixDeVente() + " euros");
        }

        // Affichage des entrées
        System.out.println("\nNos entrées :");
        for (Plat entree : carte.getEntrees()) {
            System.out.println("\t" + entree.getNom() + " - " + entree.getPrixDeVente() + " euros");
        }

        // Affichage des plats principaux
        System.out.println("\nNos plats :");
        for (Plat plat : carte.getPlatsPrincipaux()) {
            System.out.println("\t" + plat.getNom() + " - " + plat.getPrixDeVente() + " euros");
        }

        // Affichage des desserts
        System.out.println("\nNos desserts :");
        for (Plat dessert : carte.getDesserts()) {
            System.out.println("\t" + dessert.getNom() + " - " + dessert.getPrixDeVente() + " euros");
        }
    }
}
