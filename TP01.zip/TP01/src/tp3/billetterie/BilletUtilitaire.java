package tp3.billetterie;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class BilletUtilitaire {
    public static double arrondir(double prix) {
        DecimalFormat df = new DecimalFormat("0.00");
        String formattedPrice = df.format(prix);
        formattedPrice = formattedPrice.replace(',', '.');
        return Double.parseDouble(formattedPrice);
    }


    public static void afficheTrajets(ArrayList<Trajet> trajets) {
        System.out.println("\n----- Les trajets -----");
        for (Trajet trajet : trajets) {
            System.out.println(trajet.toString());
        }
    }

    public static void afficheBillets(ArrayList<Billet> billets) {
        System.out.println("\n----- Les billets -----");
        for (Billet billet : billets) {
            System.out.println(billet.toString());
        }
    }

    public static void afficheBilletsReduits(ArrayList<BilletReduit> billetsReduits) {
        System.out.println("\n----- Les billets -----");
        for (BilletReduit billetReduit : billetsReduits) {
            System.out.println(billetReduit.toString());
        }
    }
}
