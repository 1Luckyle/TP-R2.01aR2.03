package tp3.billetterie;

public class Trajet {
    /* Initialisation des variables [Attributs de classe] */
    private String depart;
    private String arrivee;
    private int distance;

    /* BILLET */
    public Trajet(String depart, String arrivee, int distance) {
        setDepart(depart);
        setArrivee(arrivee);
        setDistance(distance);
    }

    /* GETTERS / ACCESSEURS*/
    public String getDepart() {
        return depart.toUpperCase();
    }
    public String getArrivee() {
        return arrivee.toUpperCase();
    }
    public int getDistance() {
        if (distance < 5) {
            return 5;
        } else if (distance > 2000) {
            return 2000;
        } else {
            return distance;
        }
    }

    /* SETTERS */
    public void setDepart(String depart) {
        this.depart = depart;
    }
    public void setArrivee(String arrivee) {
        this.arrivee = arrivee;
    }
    public void setDistance(int distance) {
        this.distance = distance;
    }

    /* AFFICHAGE */
    @Override
    public String toString() {
        return this.getClass().getSimpleName().concat(" : " + getDepart() + " -> " + getArrivee() + " (" + getDistance() + " km)");
    }
}
