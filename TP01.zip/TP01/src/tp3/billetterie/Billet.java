package tp3.billetterie;

public class Billet {
    /* Initialisation des variables [Attributs de classe] */
    private double prixAuKm;
    private Trajet trajets;

    /* BILLET */
    public Billet(Trajet trajets, double prixAuKm) {
        this.trajets = trajets;
        setPrixAuKm(prixAuKm);
    }

    /* GETTERS / ACCESSEURS*/
    public String getDepart() {
        return trajets.getDepart();
    }
    public String getArrivee() {
        return trajets.getArrivee();
    }
    public int getDistance() {
        return trajets.getDistance();
    }
    public double getPrixAuKm() {
        if (prixAuKm < 0.1) {
            return prixAuKm = 0.1;
        } else if (prixAuKm > 2) {
            return prixAuKm = 2;
        } else {
            return prixAuKm;
        }
    }
    public double getPrix() {
        return BilletUtilitaire.arrondir(prixAuKm * getDistance());
    }

    /* SETTERS */
    public void setPrixAuKm(double prixAuKm) {
        this.prixAuKm = prixAuKm;
    }

    /* AFFICHAGE */
    @Override
    public String toString() {
        return this.getClass().getSimpleName().concat(" : [Trajet : ").concat(getDepart()).concat(" -> " + getArrivee()).concat(" (" + getDistance() + " km)]").concat(", Prix : " + getPrix() + " euros");
    }
}
