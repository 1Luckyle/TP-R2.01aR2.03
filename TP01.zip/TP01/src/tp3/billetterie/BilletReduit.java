package tp3.billetterie;

public class BilletReduit extends Billet {
    /* Initialisation des variables [Attributs de classe] */
    private double tauxDeReduction;

    /* BILLET */
    public BilletReduit(Trajet trajet, double prixAuKm, double tauxDeReduction) {
        super(trajet, prixAuKm);
        this.tauxDeReduction = tauxDeReduction;
    }

    /* GETTERS / ACCESSEURS*/
    public double getTauxDeReduction() {
        return tauxDeReduction * 100;
    }
    public double getPrix() {
        double prix = super.getPrix();
        double prixReduit = prix * (1 - tauxDeReduction);
        return BilletUtilitaire.arrondir(prixReduit);
    }

    /* SETTERS */
    public void setTauxDeReduction(double tauxDeReduction) {
        this.tauxDeReduction = tauxDeReduction;
    }

    /* AFFICHAGE */
    @Override
    public String toString() {
        return this.getClass().getSimpleName().concat(" : [Trajet : ").concat(getDepart()).concat(" -> " + getArrivee()).concat(" (" + getDistance() + " km)]").concat(", Prix : " + getPrix() + " euros").concat(", avec une réduction de " + getTauxDeReduction() + "%");
    }
}
