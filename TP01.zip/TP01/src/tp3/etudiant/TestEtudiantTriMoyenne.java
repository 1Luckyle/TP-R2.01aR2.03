package tp3.etudiant;

import tp2.universite.Etudiant;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class TestEtudiantTriMoyenne {
    public static void main(String[] args) {
        // Créer les étudiants
        Etudiant etudiant1 = new Etudiant("login1", "Floriant", "Sanz");
        Etudiant etudiant2 = new Etudiant("login2", "Pierre-antoine", "Porte");
        Etudiant etudiant3 = new Etudiant("login3", "Nils", "Burlat");
        Etudiant etudiant4 = new Etudiant("login4", "Raphaël", "Brunet-manquat");
        Etudiant etudiant5 = new Etudiant("login5", "Maxime", "Brunet-manquat");

        // Ajouter des notes aux étudiants
        etudiant1.Note(16);
        etudiant2.Note(9);
        etudiant3.Note(13);
        etudiant4.Note(19);
        etudiant5.Note(18);

        // Créer la liste d'étudiants et ajouter les étudiants
        ArrayList<Etudiant> mesEtudiantsTries = new ArrayList<>();
        mesEtudiantsTries.add(etudiant1);
        mesEtudiantsTries.add(etudiant2);
        mesEtudiantsTries.add(etudiant3);
        mesEtudiantsTries.add(etudiant4);
        mesEtudiantsTries.add(etudiant5);

        // Afficher les étudiants avant le tri
        System.out.println("--------------");
        System.out.println("Les étudiants avant Collections.sort() :");
        afficherEtudiants(mesEtudiantsTries);

        // Trier la liste d'étudiants
        Collections.sort(mesEtudiantsTries, Comparator.comparingDouble(Etudiant::Moyenne));

        // Afficher les étudiants après le tri
        System.out.println("--------------");
        System.out.println("Les étudiants après Collections.sort() :");
        afficherEtudiants(mesEtudiantsTries);
        System.out.println("--------------");
    }

    private static void afficherEtudiants(ArrayList<Etudiant> etudiants) {
        for (Etudiant etudiant : etudiants) {
            System.out.println("Moyenne = " + etudiant.Moyenne() + " : " + etudiant.getNom() + ", " + etudiant.getPrenom());
        }
    }
}
