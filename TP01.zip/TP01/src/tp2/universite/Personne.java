package tp2.universite;

public abstract class Personne {
    /**
     * La classe Personne représente la notion d'étudiant (login, nom, prénom et adresse).
     * ATTENTION des contraintes sur la notion d’étudiant :
     * – un étudiant doit toujours avoir un login en minuscule
     * – un étudiant doit toujours avoir un nom et un prénom avec le premier caractère en majuscule et les autres en minuscule.
     */
        /* Initialisation des variables [Attributs de classe] */
        private String login, prenom, nom, adresse;

        /* CONSTRUCTEURS - PERSONNNE */
        public Personne(String login, String prenom, String nom) {
            setLogin(login);
            setPrenom(prenom.toLowerCase());
            setNom(nom.toLowerCase());
        }
        public Personne(String login, String prenom, String nom, String adresse) {
            setLogin(login);
            setPrenom(prenom.toLowerCase());
            setNom(nom.toLowerCase());
            setAdresse(adresse);
        }

        /* GETTERS / ACCESSEURS */
        public String getLogin() {
            return login;
        }
        public String getPrenom() {
            return prenom;
        }
        public String getNom() {
            return nom;
        }
        public String getAdresse() {
            return adresse;
        }
        public String getNomComplet() {
            return nom.concat(prenom);
        }
        public abstract String getMail();

        /* VERIFICATEURS : */
        public boolean existAdresse() {
          return adresse != null && !adresse.isEmpty(); // Vérifier si l'adresse n'est pas nulle et n'est pas vide
//            return getAdresse() != null && !getAdresse().isEmpty();
        }

        /* SETTERS */
        public void setLogin(String login) {
            this.login = login.toLowerCase();
        }
        public void setPrenom(String prenom) {
            this.prenom = UniversiteUtilitaire.capitalize(prenom);;;
        }
        public void setNom(String nom) {
            this.nom = UniversiteUtilitaire.capitalize(nom);;
        }
        public void setAdresse(String adresse) {
            this.adresse = adresse;
        }
    }
