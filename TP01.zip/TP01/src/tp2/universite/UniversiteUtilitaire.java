package tp2.universite;

public class UniversiteUtilitaire {
    public static String capitalize(String maChaine) {
        if (maChaine == null || maChaine.isEmpty()) {
            return maChaine;
        }
        return maChaine.substring(0, 1).toUpperCase() + maChaine.substring(1);
    }

    public static void affichePersonne(Personne etudiant) {
        System.out.println("\n|━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━|");
        System.out.println("Login : " + etudiant.getLogin());
        System.out.println("Nom complet : " + etudiant.getNomComplet());
        System.out.println("Mail : " + etudiant.getMail());
        System.out.println("Adresse : " + (etudiant.existAdresse() ? etudiant.getAdresse() : "Aucune Adresse"));;
        System.out.println("|━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━|");
    }

    public static void affichePersonnel(Personnel personnel) {
        System.out.println("\n|━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━|");
        System.out.println("Login : " + personnel.getLogin());
        System.out.println("Nom complet : " + personnel.getNomComplet());
        System.out.println("Mail : " + personnel.getMail());
        System.out.println("Adresse : " + (personnel.existAdresse() ? personnel.getAdresse() : "Aucune Adresse"));;
        System.out.println("Echelon : " + personnel.getEchelon());
        System.out.println("Point d'indice : " + personnel.getPointDIndice());
        System.out.println("Salaire : " + personnel.getSalaire());
        System.out.println("|━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━|");
    }
}
