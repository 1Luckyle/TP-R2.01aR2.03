package tp2.universite;

import java.util.Collection;

public class Etudiant extends Personne implements Comparable<Etudiant> {
    /* Initialisation des variables [Attributs de classe] */
    private String adresseParent;
    private int nbNotes = 0;
    private double Note = 0.0;
    private Groupe groupe;

    /* CONSTRUCTEURS - ETUDIANT */
    public Etudiant(String login, String prenom, String nom) {
        super(login, prenom, nom);
    }

    public Etudiant(String login, String prenom, String nom, String adresse, String adresseParent) {
        super(login, prenom, nom, adresse);
        setAdresse(adresse, adresseParent);
    }

    /* GETTERS / ACCESSEURS */
    public String getAdresse() {
        if (super.existAdresse()) {
            if (adresseParent != null) {
                return super.getAdresse().concat(" (Adresse des parents : ").concat(adresseParent).concat(")");
            } else {
                return super.getAdresse();
            }
        } else {
            return adresseParent != null ? adresseParent : "Aucune adresse";
        }
    }

    public void Note(int note) {
        Note += note;
        nbNotes++;
    }

    public double Moyenne() {
        if (nbNotes == 0) {
            return 0.0;
        } else {
            return Note / nbNotes;
        }
    }

    public String getMail() {
        return super.getPrenom().concat(".").concat(super.getNom()).concat("@").concat("etu.univ-grenoble-alpes.fr");
    }

    public Groupe getGroupe() {
        return groupe;
    }

    public boolean isContainedGroupe(Groupe groupe) {
        return this.groupe == groupe;
    }

    /* VERIFICATEURS : */
    public boolean existAdresse() {
        return super.existAdresse() || (adresseParent !=null && !adresseParent.isEmpty());
    }

    public boolean existGroupe() {
        return groupe != null;
    }

    /* SETTERS */
    public void setAdresse(String adresse, String adresseParent) {
        super.setAdresse(adresse);
        this.adresseParent = adresseParent;
    }

    public void setGroupe(Groupe groupe) {
        this.groupe = groupe;
    }

    /* AFFICHAGE */
    @Override
    public int compareTo(Etudiant autreEtudiant) {
        int compareNom = this.getNom().compareTo(autreEtudiant.getNom());
        if (compareNom != 0) {
            return compareNom;
        } else {
            return this.getPrenom().compareTo(autreEtudiant.getPrenom());
        }
    }
}
