package tp2.universite;

public class Personnel extends Personne {
    /* Initialisation des variables [Attributs de classe] */
    private int echelon;
    private double pointDIndice;
    public static final int ECHELON_MIN = 1;
    public static final int ECHELON_MAX = 4;
    public static final int POINTDINDICE_MIN = 1000;
    public static final int POINTDINDICE_MAX = 1200;

    /* CONSTRUCTEURS - PERSONNNEL */
    public Personnel(String login, String prenom, String nom) {
        super(login, prenom, nom);
    }
    public Personnel(String login, String prenom, String nom, int echelon, double pointDIndice) {
        super(login, prenom, nom);
        setEchelon(echelon);
        setPointDIndice(pointDIndice);
    }

    /* GETTERS / ACCESSEURS */
    public int getEchelon() {
        if (echelon <= ECHELON_MIN) {
            return echelon = 1;
        } else if (echelon >= ECHELON_MAX) {
            return echelon = 4;
        } else {
            return echelon;
        }
    }
    public double getPointDIndice() {
        if (pointDIndice < POINTDINDICE_MIN) {
            return pointDIndice = 1000;
        } else if (pointDIndice > POINTDINDICE_MAX) {
            return pointDIndice = 1200;
        } else {
            return pointDIndice;
        }
    }
    public double getSalaire() {
        return echelon*pointDIndice;
    }

    public String getMail() {
        return super.getPrenom().concat(".").concat(super.getNom()).concat("@").concat("etu.univ-grenoble-alpes.fr");
    }

    /* SETTERS */
    public void setEchelon(int echelon) {
        this.echelon = echelon;
    }
    public void setPointDIndice(double pointDIndice) {
        this.pointDIndice = pointDIndice;
    }
}
