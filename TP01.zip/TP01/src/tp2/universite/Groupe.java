package tp2.universite;

import java.util.ArrayList;
import java.util.Collection;

public class Groupe {
    /* Initialisation des variables [Attributs de classe] */
    private String libelle;
    private Collection<Etudiant> etudiants;

    /* CONSTRUCTEURS - GROUPE */
    public Groupe(String libelle) {
        setLibelle(libelle);
        this.etudiants = new ArrayList<>();
    }

    /* GETTERS / ACCESSEURS */
    public String getLibelle() {
        return libelle;
    }

    public Collection<Etudiant> getEtudiants() {
        return etudiants;
    }

    public void addEtudiant(Etudiant etudiant) {
        if (!containsEtudiant(etudiant)) {
            etudiants.add(etudiant);
            etudiant.setGroupe(this);
        }
    }

    public void removeEtudiant(Etudiant etudiant) {
        if (containsEtudiant(etudiant)) {
            etudiants.remove(etudiant);
            etudiant.setGroupe(null);
        }
    }

    public boolean containsEtudiant(Etudiant etudiant) {
        return etudiants.contains(etudiant);
    }

    /* SETTERS */
    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }
}
