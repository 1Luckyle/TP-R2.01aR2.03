package tp2.contrainte;

public class ContrainteUtilitaire {
}
