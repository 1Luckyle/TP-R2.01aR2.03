package tp2.contrainte;

import java.util.Scanner;

public class ReelContraint {
    /* Initialisation des variables [Attributs de classe] */
    private double min, max, valeur;

    /* CONSTRUCTEURS : REEL CONTRAINTE */
    public ReelContraint(double min, double max) {

    }

    /* GETTERS / ACCESSEURS */
    public double getValeur() {
        return valeur;
    }

    /* SETTERS */
    public void setValeur(double valeur) {
        this.valeur = valeur;
    }

    /* TO STRING */
    @Override
    public String toString() {
        return "« valeur : X, min : Y, max : Z »";
    }

    /* METHODES */
    public ReelContraint saisir(double min, double max) {
        Scanner lecteur = new Scanner(System.in);
        do {
            System.out.print("Saisissez une valeur compris entre " + min + " et " + max + " : ");
            valeur = lecteur.nextDouble();
            lecteur.nextLine();
            if (valeur < min || valeur > max) {
                System.out.println("Veuillez saisir une valeur compris entre " + min + " et " + max + " !");
            }
        } while (valeur < min || valeur > max);
        return null;
    }
}
