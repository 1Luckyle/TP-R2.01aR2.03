package tp2.contrainte;

public class TestContrainte {
}
