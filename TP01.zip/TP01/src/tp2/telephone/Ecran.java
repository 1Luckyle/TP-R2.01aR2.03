package tp2.telephone;

/**
 * La classe Ecran représente l'écran d'un téléphone.
 */
public class Ecran {
    /** Le type d'écran (par exemple: LCD, LED, AMOLED). */
    private String type;

    /** La taille de l'écran en pouces. */
    private int taille;

    /**
     * Constructeur de la classe Ecran.
     *
     * @param type Le type d'écran.
     * @param taille La taille de l'écran en pouces.
     */
    public Ecran(String type, int taille) {
        this.type = type;
        this.taille = taille;
    }

    /**
     * Renvoie le type d'écran.
     *
     * @return Le type d'écran.
     */
    public String getType() {
        return type;
    }

    /**
     * Renvoie la taille de l'écran en pouces.
     *
     * @return La taille de l'écran.
     */
    public int getTaille() {
        return taille;
    }
}
