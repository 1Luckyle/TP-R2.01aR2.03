package tp2.telephone;

/**
 * La classe Processeur représente le processeur d'un téléphone, caractérisée par son type et sa fréquence.
 */
public class Processeur {
    private String libelle;    // Le libellé du processeur
    private double frequence;  // La fréquence du processeur en GHz

    /**
     * Constructeur de la classe Processeur.
     *
     * @param libelle Le libellé du processeur.
     * @param frequence La fréquence du processeur en GHz.
     */
    public Processeur(String libelle, double frequence) {
        this.libelle = libelle;
        this.frequence = frequence;
    }

    /**
     * Récupère le libellé du processeur.
     *
     * @return Le libellé du processeur.
     */
    public String getLibelle() {
        return libelle;
    }

    /**
     * Récupère la fréquence du processeur.
     *
     * @return La fréquence du processeur en GHz.
     */
    public double getFrequence() {
        return frequence;
    }
}
