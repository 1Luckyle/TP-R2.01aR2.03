package tp2.telephone;

/**
 * La classe Memoire représente la mémoire d'un téléphone, caractérisée par son type et sa capacité en gigaoctets.
 */
public class Memoire {
    private String type; // Le type de mémoire du téléphone
    private int nombreGiga; // La capacité de la mémoire en gigaoctets

    /**
     * Constructeur de la classe Memoire.
     *
     * @param type       Le type de mémoire (ex: "RAM", "stockage interne", etc.)
     * @param nombreGiga La capacité de la mémoire en gigaoctets
     */
    public Memoire(String type, int nombreGiga) {
        this.type = type;
        this.nombreGiga = nombreGiga;
    }

    /**
     * Getter pour obtenir le type de mémoire.
     *
     * @return Le type de mémoire du téléphone
     */
    public String getType() {
        return type;
    }

    /**
     * Getter pour obtenir la capacité de la mémoire.
     *
     * @return La capacité de la mémoire en gigaoctets
     */
    public int getNombreGiga() {
        return nombreGiga;
    }
}

