package tp2.telephone;

/**
 * La classe TestTelephone permet de tester la création et l'affichage de différents téléphones.
 */
public class TestTelephone {
    /**
     * Méthode principale permettant de créer des téléphones avec différentes configurations et de les afficher.
     *
     * @param args Les arguments de la ligne de commande (non utilisés dans cette application).
     */
    public static void main(String[] args) {
        // Création des processeurs
        Processeur processeur1 = new Processeur("Octa-Core (2.84GHz)", 2.84);
        Processeur processeur2 = new Processeur("Octa-Core (3.0GHz)", 3.0);

        // Création des mémoires RAM
        Memoire ram1 = new Memoire("LPDDR5 4G", 4);
        Memoire ram2 = new Memoire("LPDDR5 8G", 8);

        // Création des mémoires de stockage
        Memoire stockage1 = new Memoire("UFS Storage 3.1", 64);
        Memoire stockage2 = new Memoire("UFS Storage 3.1", 128);
        Memoire stockage3 = new Memoire("UFS Storage 3.1", 256);

        // Création des écrans
        Ecran ecran1 = new Ecran("Amoled", 5);
        Ecran ecran2 = new Ecran("Amoled", 6);
        Ecran ecran3 = new Ecran("Amoled", 7);

        // Construction des téléphones avec différentes configurations
        Telephone telephone1 = new Telephone("Bas de gamme", processeur1, stockage1, ecran1);
        telephone1.addRam(ram1);

        Telephone telephone2 = new Telephone("Bas de gamme+", processeur1, stockage2, ecran1);
        telephone2.addRam(ram1);
        telephone2.addRam(ram1);

        Telephone telephone3 = new Telephone("Milieu de gamme", processeur1, stockage2, ecran2);
        telephone3.addRam(ram1);
        telephone3.addRam(ram1);

        Telephone telephone4 = new Telephone("Haut de gamme", processeur2, stockage3, ecran3);
        telephone4.addRam(ram2);
        telephone4.addRam(ram2);

        // Affichage des téléphones
        System.out.println(telephone1);
        System.out.println(telephone2);
        System.out.println(telephone3);
        System.out.println(telephone4);
    }
}
