package tp2.telephone;

import java.util.ArrayList;
import java.util.List;

/**
 * La classe Telephone représente l'ensemble d'un téléphone.
 */
public class Telephone {
    private String libelle;          // Le libellé du téléphone
    private Processeur processeur;  // Le processeur du téléphone
    private List<Memoire> memoires; // Liste des mémoires RAM du téléphone
    private Memoire stockage;       // La mémoire de stockage du téléphone
    private Ecran ecran;            // L'écran du téléphone

    /**
     * Constructeur de la classe Telephone.
     *
     * @param libelle Le libellé du téléphone.
     * @param processeur Le processeur du téléphone.
     * @param stockage La mémoire de stockage du téléphone.
     * @param ecran L'écran du téléphone.
     */
    public Telephone(String libelle, Processeur processeur, Memoire stockage, Ecran ecran) {
        this.libelle = libelle;
        this.processeur = processeur;
        this.memoires = new ArrayList<>();
        this.stockage = stockage;
        this.ecran = ecran;
    }

    /**
     * Ajoute une mémoire RAM au téléphone.
     *
     * @param ram La mémoire RAM à ajouter.
     */
    public void addRam(Memoire ram) {
        memoires.add(ram);
    }

    /**
     * Calcule le nombre total de gigaoctets de RAM du téléphone.
     *
     * @return Le nombre total de gigaoctets de RAM du téléphone.
     */
    public int getNombreGigaRam() {
        int totalRam = 0;
        for (Memoire ram : memoires) {
            totalRam += ram.getNombreGiga();
        }
        return totalRam;
    }

    /**
     * Override de la méthode toString() pour afficher les informations du téléphone.
     *
     * @return Les informations du téléphone sous forme de chaîne de caractères.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(libelle).append(", processeur = ").append(processeur.getLibelle())
                .append(" (").append(processeur.getFrequence()).append("GHz), ram = ");
        if (!memoires.isEmpty()) {
            sb.append(getNombreGigaRam()).append("Giga [");
            for (int i = 0; i < memoires.size(); i++) {
                sb.append(memoires.get(i).getType());
                if (i < memoires.size() - 1) {
                    sb.append(" + ");
                }
            }
            sb.append("], stockage = [").append(stockage.getType()).append(", ")
                    .append(stockage.getNombreGiga()).append("Giga], ecran = [")
                    .append(ecran.getType()).append(", ").append(ecran.getTaille())
                    .append(" pouces]\n");
        }
        return sb.toString();
    }
}
