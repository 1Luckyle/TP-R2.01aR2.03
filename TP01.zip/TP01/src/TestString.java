import java.util.Scanner;
import java.lang.StringBuilder;

public class TestString {
    public static void main(String[] args) {
        /* Initialisation des variables */
        Scanner lecteur = new Scanner(System.in);
        String maChaine;

        /* Lecteur de saisie des caractères */
        System.out.print("Donner une chaîne de caractères maChaine : ");
        maChaine = lecteur.next();

        /* Zone de test */
        System.out.println("La variable maChaine vaut : " + maChaine);
        System.out.println("1. Nombre de caractères de la chaîne de caractères maChaine : " + maChaine.length()); // l'attribut .length permet de connaitre la longueur
        System.out.println("2. La chaîne de caractères maChaine en majuscule : " + maChaine.toUpperCase()); // l'attribut .toUpperCase permet de mettre la chaine de caractère en majuscule (inverse : .ToLowerCase)
        System.out.print("3. Donner une deuxieme chaîne de caractères deuxiemeChaine : ");
        String deuxiemeChaine = lecteur.next();
        System.out.println("Les deux chaînes sont identiques ou non - sans tenir compte de la casse. : " + maChaine.equalsIgnoreCase(deuxiemeChaine)); // permet de comparer les chaines de caractère

        /* Vérifie si la chaine de caractère est en minuscule */
        if (maChaine == maChaine.toLowerCase()) {
            System.out.println("4. La chaîne de caractères maChaine est en minuscule");
        } else {
            System.out.println("4. La chaîne de caractères maChaine est en majuscule");
        }

        System.out.println("5. La chaîne de caractères maChaine en majuscule sans les 'blancs' en début et fin de chaîne : " + maChaine.toUpperCase().trim()); // permet d'enlever les blancs au debut et à la fin

        StringBuilder maChainePalindrome = new StringBuilder(); // construit un nouveau StringBuilder
        maChainePalindrome.append(maChaine); // affecte maChaine à la variable StringBuilder
        maChainePalindrome = maChainePalindrome.reverse(); // permet d'inverser les caractères

        /* Vérifie si maChaine est un palindrôme */
        if (maChaine.equals(String.valueOf(maChainePalindrome))) { // compare si maChaine est égal à maChainePalindrome
            System.out.println("6. La chaîne de caractères maChaine est un palindrome.");
        } else {
            System.out.println("6. La chaîne de caractères maChaine n'est pas un palindrome.");
        }
    }
}
